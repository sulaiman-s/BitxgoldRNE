import {ImageRequireSource, ImageSourcePropType} from 'react-native';

export enum Status_Types_Enum {
  Online,
  Offline,
}

export enum Animation_Types_Enum {
  SlideTop,
  SlideBottom,
  SlideInRight,
  SlideInLeft,
}
