import * as React from "react";
import { FlatList, Image } from "react-native";
import { NavigationProp, useNavigation } from "@react-navigation/native";
import {
  Button,
  StyleService,
  TopNavigation,
  useStyleSheet,
} from "@ui-kitten/components";
import { Container, Text } from "components";
import { RootStackParamList } from "navigation/navigation-types";
import { useLayout } from "hooks";
import ButtonSpash, { ButtonSpashProps } from "./ButtonSpash";
import Images from "assets/images";
import { waitUtil } from "utils/waitUtil";

const SplashScreen = React.memo(() => {
  const { navigate } = useNavigation<NavigationProp<RootStackParamList>>();
  const styles = useStyleSheet(themedStyles);

  const data: ButtonSpashProps[] = [
    {
      title: "Authenticate",
      data: [
        {
          name: "SignIn 01",
          navigate: () => navigate("Auth", { screen: "SignIn01" }),
        },
        {
          name: "SignIn 02",
          navigate: () => navigate("Auth", { screen: "SignIn02" }),
        },
        {
          name: "SignIn 03",
          navigate: () => navigate("Auth", { screen: "SignIn03" }),
        },
        {
          name: "SignUp 01",
          navigate: () => navigate("Auth", { screen: "SignUp01" }),
        },
        {
          name: "SignUp 02",
          navigate: () => navigate("Auth", { screen: "SignUp02" }),
        },
        {
          name: "SignUp 03",
          navigate: () => navigate("Auth", { screen: "SignUp03" }),
        },
        {
          name: "Forgot Password",
          navigate: () => navigate("Auth", { screen: "ForgotPassword" }),
        },
        {
          name: "Verify",
          navigate: () => navigate("Auth", { screen: "Verify" }),
        },
        {
          name: "Create Account",
          navigate: () => navigate("Auth", { screen: "CreateAccount" }),
        },
        {
          name: "Authenticate",
          navigate: () => navigate("Auth", { screen: "Authenticate" }),
        },
      ],
    },
    {
      title: "Profile",
      data: [
        {
          name: "Profile 01",
          navigate: () => navigate("Profile", { screen: "Profile01" }),
        },
        {
          name: "Profile 02",
          navigate: () => navigate("Profile", { screen: "Profile02" }),
        },
        {
          name: "Profile 03",
          navigate: () => navigate("Profile", { screen: "Profile03" }),
        },
        {
          name: "Profile 04",
          navigate: () => navigate("Profile", { screen: "Profile04" }),
        },
        {
          name: "Profile 05",
          navigate: () => navigate("Profile", { screen: "Profile05" }),
        },
        {
          name: "Profile 06",
          navigate: () => navigate("Profile", { screen: "Profile06" }),
        },
        {
          name: "Profile 07",
          navigate: () => navigate("Profile", { screen: "Profile07" }),
        },
        {
          name: "Profile 08",
          navigate: () => navigate("Profile", { screen: "Profile08" }),
        },
        {
          name: "Profile 09",
          navigate: () => navigate("Profile", { screen: "Profile09" }),
        },
        {
          name: "Profile 10",
          navigate: () => navigate("Profile", { screen: "Profile10" }),
        },
      ],
    },
    {
      title: "Reading",
      data: [
        {
          name: "01. Home Reading",
          navigate: () => navigate("Reading", { screen: "Reading01" }),
        },
        {
          name: "02. List Book",
          navigate: () => navigate("Reading", { screen: "Reading02" }),
        },
        {
          name: "03. Book Details",
          navigate: () => navigate("Reading", { screen: "Reading03" }),
        },
        {
          name: "04. Question",
          navigate: () => navigate("Reading", { screen: "Reading04" }),
        },
        {
          name: "05. Listen Book",
          navigate: () => navigate("Reading", { screen: "Reading05" }),
        },
        {
          name: "06. Bookmark Collection",
          navigate: () => navigate("Reading", { screen: "Reading06" }),
        },
        {
          name: "07. Bookmark List",
          navigate: () => navigate("Reading", { screen: "Reading07" }),
        },
        {
          name: "08. Checkout",
          navigate: () => navigate("Reading", { screen: "Reading08" }),
        },
        {
          name: "09. Order Tracking",
          navigate: () => navigate("Reading", { screen: "Reading09" }),
        },
        {
          name: "10. Home-Book",
          navigate: () => navigate("Reading", { screen: "Reading10" }),
        },
      ],
    },
    {
      title: "Crypto",
      data: [
        {
          name: "01. Home Crypto",
          navigate: () => navigate("Crypto", { screen: "Crypto01" }),
        },
        {
          name: "02. List Coin Price",
          navigate: () => navigate("Crypto", { screen: "Crypto02" }),
        },
        {
          name: "03. Wallet",
          navigate: () => navigate("Crypto", { screen: "Crypto03" }),
        },
        {
          name: "04. Pool Lottery",
          navigate: () => navigate("Crypto", { screen: "Crypto04" }),
        },
        {
          name: "05. Overview",
          navigate: () => navigate("Crypto", { screen: "Crypto05" }),
        },
        {
          name: "06. Raise IDO",
          navigate: () => navigate("Crypto", { screen: "Crypto06" }),
        },
        {
          name: "07. Overview",
          navigate: () => navigate("Crypto", { screen: "Crypto07" }),
        },
        {
          name: "08. Swap",
          navigate: () => navigate("Crypto", { screen: "Crypto08" }),
        },
        {
          name: "09. Pool List",
          navigate: () => navigate("Crypto", { screen: "Crypto09" }),
        },
        {
          name: "10. Farm",
          navigate: () => navigate("Crypto", { screen: "Crypto10" }),
        },
      ],
    },
  ];
  const { width, height } = useLayout();
  const [activeIndex, setActiveIndex] = React.useState(-1);
  const refFlatList = React.useRef<FlatList>(null);

  React.useEffect(() => {
    if (activeIndex >= 0) {
      waitUtil(10).then(() => {
        refFlatList.current?.scrollToIndex({
          index: activeIndex,
          viewOffset: 0.1,
          viewPosition: 0.1,
          animated: true,
        });
      });
    }
  }, [activeIndex]);

  return (
    <Container style={styles.container}>
      <TopNavigation
        style={styles.topNavigation}
        accessoryLeft={() => <Image source={Images.logo} />}
        accessoryRight={() => (
          <Button children={"120+ screens"} style={styles.headerButton} />
        )}
      />
      <FlatList
        ref={refFlatList}
        data={data}
        contentContainerStyle={styles.content}
        renderItem={({ item, index }) => {
          return (
            <ButtonSpash
              title={item.title}
              data={item.data}
              open={activeIndex === index}
              onPress={() => {
                if (activeIndex === index) {
                  setActiveIndex(-1);
                } else {
                  setActiveIndex(index);
                }
              }}
              style={
                index === 0 &&
                styles.firstButton &&
                index === data.length - 1 &&
                styles.lastButton
              }
            />
          );
        }}
      />
    </Container>
  );
});

export default SplashScreen;

const themedStyles = StyleService.create({
  container: {
    flex: 1,
    paddingBottom: 0,
  },
  button: {
    marginBottom: 24,
    flex: 1,
    marginHorizontal: 8,
    borderRadius: 16,
  },
  content: {
    paddingBottom: 40,
    paddingTop: 24,
    borderRadius: 16,
  },
  lastButton: {
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  firstButton: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  headerButton: {
    borderRadius: 99,
  },
  topNavigation: {
    paddingHorizontal: 24,
  },
});
